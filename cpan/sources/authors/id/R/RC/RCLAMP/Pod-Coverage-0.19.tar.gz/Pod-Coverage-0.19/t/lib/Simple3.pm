package Simple3;

sub h3 {}
sub has_parens {}

1;

__END__

# test module - all covered, just make sure that we catch them properly

=head3 h3

=head2 has_parens (stuff, here)

=cut

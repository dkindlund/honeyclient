package XS4ALL;
# some failing elements of XS4ALL's house style

=head2 $self->classes;

something somthing

=cut

sub classes {}

=head2 $level = $mmdb->transaction_level;

rhubarb rhubarb

=cut

sub transaction_level {}

=head2 $self->frobnicate();

mushrooms mushrooms

=cut

sub frobnicate {}


1;


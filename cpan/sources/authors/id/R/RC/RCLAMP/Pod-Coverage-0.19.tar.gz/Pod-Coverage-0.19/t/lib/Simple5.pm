package Simple5;

=head1 NAME

=item get_foo set_foo

frob foo

=cut

sub get_foo {}
sub set_foo {}

1;
__END__

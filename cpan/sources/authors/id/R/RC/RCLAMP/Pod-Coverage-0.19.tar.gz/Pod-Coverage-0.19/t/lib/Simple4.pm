# a package with external .pod
package Simple4;

sub foo {}

1;
__END__

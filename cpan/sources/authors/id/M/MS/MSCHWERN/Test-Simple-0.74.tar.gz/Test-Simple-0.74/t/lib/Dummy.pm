package Dummy;

$VERSION = '0.01';

1;
package L4pResurrectable;
use Log::Log4perl qw(:easy);

our $VERSION = "0.01";

sub foo {
    ###l4p DEBUG "foo was here";
    ###l4p INFO  "bar was here";
}

1;

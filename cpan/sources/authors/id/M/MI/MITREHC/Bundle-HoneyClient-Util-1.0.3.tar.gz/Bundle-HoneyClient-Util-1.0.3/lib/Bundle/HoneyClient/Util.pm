package Bundle::HoneyClient::Util;

use warnings;
use strict;

=head1 NAME

Bundle::HoneyClient::Util - The great new Bundle::HoneyClient::Util!

=head1 VERSION

Version 1.0.3

=cut

our $VERSION = '1.0.3';

1; # End of Bundle::HoneyClient::Util

=head1 SYNOPSIS

Quick summary of what the module does.

=head1 CONTENTS
#Indentation and grouping indicates prerequisites...
#just for my own benefit - Xeno

#To be in this list, an item should either be used in HC::Util 
#proper, or be used, or be the prerequisite of something which 
#is used, in both Manager and Agent
#Ideally there should be no duplication between this and the
#bundles for Manager or Agent, but it won't hurt *too* much 
#if there is (however, some dumb packages will always re-run
#their tests for instance, so you should still try to avoid it
#if at all possible)

 URI
     Compress::Raw::Zlib
     IO::Compress::Base
       Compress::Raw::Bzip2
      IO::Compress::Bzip2
     IO::Compress::Gzip -- aka IO::Compress::Zlib
    Compress::Zlib
   HTML::Tagset
   HTML::Parser
  LWP #aka LWP::UserAgent
 XML::Parser
XML::XPath
#Used in Util
  
    Devel::Symdump
   Pod::Coverage
  Test::Pod::Coverage
    Pod::Escapes
   Pod::Simple
  Test::Pod
 Math::BaseCnv
XML::Tidy
#Used in Util

Log::Log4perl
#Used in Util, Manager, Agent

 Params::Validate
 Module::Build
Log::Dispatch::Syslog
#used in Util

# XML::Parser - should already be installed - shouldn prompt
SOAP::Lite
#Used in Util

  Date::Parse
  Date::Format
    Pod::Escapes
   Pod::Simple
  Test::Pod
 Mail::Field
 IO::Stringy
 File::Temp
MIME::Tools
#Used in ???

#Sys::Syslog
#Used in HoneyClient/Util

 DateTime::Locale
  Class::Singleton
 DateTime::TimeZone
DateTime
#Depended upon by things in Manager, Agent
DateTime::HiRes
#Used in Manager/Agent, depends on DateTime

  Net::Domain::TLD
 Data::Validate::Domain
  Net::Netmask
 Data::Validate::IP
Data::Validate::URI

threads
#Used in Manager, Agent

threads::shared
#Used in Manager, Agent


package Bundle::HoneyClient::Agent;

use warnings;
use strict;

=head1 NAME

Bundle::HoneyClient::Agent - The great new Bundle::HoneyClient::Agent!

=head1 VERSION

Version 1.0.1

=cut

our $VERSION = '1.0.1';

1; # End of Bundle::HoneyClient::Agent

=head1 SYNOPSIS

Quick summary of what the module does.

=head1 CONTENTS

Digest::SHA

File::Type

 Sub::Uplevel
 Test::Simple -- aka Test::Builder, Test::Builder::Tester, Test::More
Test::Exception

  Number::Compare
  Text::Glob
 File::Find::Rule
Data::Compare

#Win32::Job -- to be installed through cygwin


package Bundle::HoneyClient::Manager;

use warnings;
use strict;

=head1 NAME

Bundle::HoneyClient::Manager - The great new Bundle::HoneyClient::Manager!

=head1 VERSION

Version 1.0.1

=cut

our $VERSION = '1.0.1';

1; # End of Bundle::HoneyClient::Manager

=head1 SYNOPSIS

Quick summary of what the module does.

=head1 CONTENTS

ExtUtils::CBuilder
ExtUtils::MakeMaker 
ExtUtils::ParseXS
Sys::Hostname::Long 
Sys::HostIP
Digest::SHA1
Digest::HMAC_MD5
Net::IP
Net::DNS
XML::TreePP
XML::RPC
Task::Weaken
DateTime::Format::Strptime
Class::Factory::Util
DateTime::Format::Builder
DateTime::Format::ISO8601
Proc::ProcessTable
Log::Dispatch
Clone
Data::Structure::Util
Class::MethodMaker
Test::Simple
Sub::Uplevel
Sys::Syslog
YAML::XS

#include "local_types.h"

unsigned char *ipt_gen_delmask(ENTRY *);
